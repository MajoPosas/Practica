const contexto = {
    imagenes: [
        { url: 'https://picsum.photos/200', descripcion: 'Imagen 1' },
        { url: 'https://picsum.photos/300', descripcion: 'Imagen 2' },
        { url: 'https://picsum.photos/500', descripcion: 'Imagen 3' },
        { url: 'https://picsum.photos/220', descripcion: 'Imagen 4' },
        { url: 'https://picsum.photos/110', descripcion: 'Imagen 5' },
        { url: 'https://picsum.photos/560', descripcion: 'Imagen 6' },
        { url: 'https://picsum.photos/90', descripcion: 'Imagen 7' },
        { url: 'https://picsum.photos/230', descripcion: 'Imagen 8' },
        { url: 'https://picsum.photos/20', descripcion: 'Imagen 9' },
        { url: 'https://picsum.photos/10', descripcion: 'Imagen 10' },
        { url: 'https://picsum.photos/50', descripcion: 'Imagen 11' },
        { url: 'https://picsum.photos/470', descripcion: 'Imagen 12' },
        { url: 'https://picsum.photos/940', descripcion: 'Imagen 13' },
        { url: 'https://picsum.photos/180', descripcion: 'Imagen 14' },
        { url: 'https://picsum.photos/230', descripcion: 'Imagen 15' },
        
    ]
};
